

# Face-Detection

* Detect your face using 5 dots

![](https://img.shields.io/pypi/l/hashlib?color=yellow&logo=python)
![python](https://img.shields.io/badge/Python-v3.10-3776AB?style=for_the_badge&logo=Python)



# How it works?

* In this program we are using a package called ```Mediapipe``` to make it Detect are face.
* Also we are using ```cv2``` to make the frame to capture the face to detect.
* Then we write the code to make te dots move when we move are face.
* To make the code to the next level we made a simple code to stop the program when we hit that button.

## Authors

- [@Minuka](https://github.com/Dontharu)


# Thank you!
